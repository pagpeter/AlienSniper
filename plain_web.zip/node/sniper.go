package node

import (
	types "Alien/types"
	"fmt"
	"strconv"
	"sync"
	"time"
)

const delay = 0

var (
	bearers MCbearers
)

func StartSniper(timestamp int64, delay int, name string, i int, payload Payload) types.Log {
	var l types.Log
	var send []time.Time
	var statuscode []int

	for g := 0; g < 2; {
		recvd := make([]byte, 4069)
		fmt.Fprintln(payload.Conns[i], payload.Payload[i])
		send = append(send, time.Now())
		payload.Conns[i].Read(recvd)
		status, _ := strconv.Atoi(string(recvd[9:12]))
		statuscode = append(statuscode, status)

		g++
	}

	l.Name = name
	l.Delay = float64(delay)
	l.Success = false

	for i, status := range statuscode {

		sent := types.Sent{
			Content: []types.RequestLog{{Timestamp: send[i].Unix(), Statuscode: status}},
			Email:   "meow",
			Ip:      "meow",
		}

		l.Sends = append(l.Sends, &sent)

		if status == 200 {
			l.Success = true
		}
	}

	l.Requests = float64(len(statuscode))

	return l
}

func StartSnipe(task types.Task) {
	accounts := task.Accounts
	droptime := task.Timestamp

	// chans := make([]chan types.Logs, len(accounts))
	var logs []types.Log
	var wg sync.WaitGroup

	bearers = bearers.AddAccounts(accounts)

	PreSleep(droptime)

	payload := bearers.CreatePayloads(task.Name)

	Sleep(droptime, delay)

	for i, _ := range payload.AccountType {
		wg.Add(1)
		go func(i int) {
			tmp := StartSniper(droptime, delay, task.Name, i, payload)
			logs = append(logs, tmp)
			// chans = append(chans, tmp)
			wg.Done()
		}(i)
	}
	wg.Wait()

	bearers = bearers.RemoveAccounts()

	var p types.Packet

	p.Type = "send_logs"
	p.Content.Logs = logs

	handleMessage(p)

}
