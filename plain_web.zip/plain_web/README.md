# Web dashboard

This is the web dashboard of alien.
It doesnt use any JS frameworks, the only framework it uses is DaisyUI for the components, and tailwindCSS.
We use Tailwind with the JIT mode.

### How to rebuild `/libs/tailwind.css`:

install node/npm

`npx tailwindcss -o libs/tailwind.css`
