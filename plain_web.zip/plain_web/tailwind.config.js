module.exports = {
  mode: 'jit',
  purge: [
    '*.{html,js}',
    'js/*.js',
  ],
}